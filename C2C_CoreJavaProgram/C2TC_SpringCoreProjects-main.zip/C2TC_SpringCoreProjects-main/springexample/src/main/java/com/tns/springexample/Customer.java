package com.tns.springexample;

public class Customer {
	public void display()
	{
		System.out.println("Welcome to the Spring core...");
	}
}
