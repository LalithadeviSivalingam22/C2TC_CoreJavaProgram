package com.tns.springcore.springbasic;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
