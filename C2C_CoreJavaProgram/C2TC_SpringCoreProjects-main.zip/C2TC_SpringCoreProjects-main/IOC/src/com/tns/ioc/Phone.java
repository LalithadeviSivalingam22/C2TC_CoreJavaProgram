package com.tns.ioc;

public interface Phone {

	void calling();
	void internet();
	
}
