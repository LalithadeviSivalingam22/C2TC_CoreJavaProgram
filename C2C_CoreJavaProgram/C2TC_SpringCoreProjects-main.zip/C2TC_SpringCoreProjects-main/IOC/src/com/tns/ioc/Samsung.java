package com.tns.ioc;

public class Samsung implements Phone{
	public void calling()
	{
		System.out.println("Calling from samsung..");
	}
	public void internet()
	{
		System.out.println("Data from samsung..");
	}
}
